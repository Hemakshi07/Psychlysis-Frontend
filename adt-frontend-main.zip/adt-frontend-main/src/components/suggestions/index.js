import { Box, Heading } from '@chakra-ui/react'
import React from 'react'

const Suggestions = () => {
  return (
    <Box>
      <Heading>Suggestions</Heading>
      <Heading size={'md'}>Coming Soon ... 🙂</Heading>
    </Box>
  )
}

export default Suggestions
