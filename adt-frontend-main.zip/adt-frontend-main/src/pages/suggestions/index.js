import React from 'react'
import Suggestions from '../../components/suggestions'

const index = () => {
  return (
    <div>
      <Suggestions />
    </div>
  )
}

export default index
