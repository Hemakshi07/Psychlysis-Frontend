import React from 'react'
import SignUp from '../components/signup/SignUp'

const signup = () => {
  return <SignUp />
}

export default signup
