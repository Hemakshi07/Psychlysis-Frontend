import React from 'react'
import Login from '../components/login/Login'

const login = () => {
  return <Login />
}

export default login
