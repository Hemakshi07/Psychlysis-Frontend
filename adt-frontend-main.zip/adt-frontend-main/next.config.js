// eslint-disable-next-line @typescript-eslint/no-var-requires
const path = require('path')

module.exports = {
  env: {
    SERVER_URL: process.env.SERVER_URL,
  },
  images: {
    domains: ['localhost'],
  },
}
